// Export pages
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/court_details/court_details_widget.dart' show CourtDetailsWidget;
export '/pages/phone_sign_in/phone_sign_in_widget.dart' show PhoneSignInWidget;
export '/pages/rate_court_page/rate_court_page_widget.dart'
    show RateCourtPageWidget;
export '/pages/barbers/barbers_widget.dart' show BarbersWidget;
export '/selectdate/selectdate_widget.dart' show SelectdateWidget;
